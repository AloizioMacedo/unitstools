# Introduction

Unitstools is a Python library that helps scientists, programmers and enthusiasts to manage units of measurement in code via static typing.

This package makes it more difficult for magic constants that actually have units to silently live in the code preventing things like a sustainable units conversion for example.