# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['unitstools']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'unitstools',
    'version': '0.1.2',
    'description': 'Unitstools is a Python library that helps to manage units of measurement in code via static typing.',
    'long_description': '# Introduction\n\nUnitstools is a Python library that helps scientists, programmers and enthusiasts to manage units of measurement in code via static typing.\n\nThis package makes it more difficult for magic constants that actually have units to silently live in the code preventing things like a sustainable units conversion for example.',
    'author': 'Aloizio Macedo',
    'author_email': 'aloiziomacedo@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/AloizioMacedo/unitstools',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
